const express = require('express')
const bodyParser = require('body-parser')
const db = require('./dbConnection');
const jwt = require('jsonwebtoken');
const cors = require('cors')
const indexRouter = require("./router")
// const indexRouter1=require('./router')
require('dotenv').config();

const app = express();
app.use(express.json())

app.use(bodyParser.json());

app.use('/',express.static("public/images"));

app.use(bodyParser.urlencoded({
    extended: true
}))

app.use(cors());

// app.use(indexRouter1)
app.use(indexRouter)


app.listen(process.env.DOIT_PORT, () => {
    console.log("Server up & Listening on port:4000")
})