require('dotenv').config();
const mysql=require('mysql');

const db=mysql.createConnection({
   
    // host:process.env.DOIT_HOST,
    // user:process.env.DOIT_DB,
    // password:process.env.DOIT_PASS,
    // database:process.env.DOIT_DB

    host:process.env.DOIT_HOST,
    user:process.env.DOIT_USER,
    password:process.env.DOIT_PASS,
    database:process.env.DOIT_DB,
    // port:process.env.DOIT_PORT   
})
 db.connect((err)=>{
    if(!err){
        console.log("Database Connected");
    }
    else{
        console.log(err)
    }
 })
module.exports=db