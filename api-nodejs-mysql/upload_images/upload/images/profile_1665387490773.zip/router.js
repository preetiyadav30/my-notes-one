const express = require('express');
const router = express.Router();

const path=require('path');
const bodyParser = require('body-parser');
const db = require("./dbConnection");
const jwt = require('jsonwebtoken');
const verifyToken = require('./validator');
const { application } = require('express');
const multer =require('multer');
const { send } = require('process');
// const upload=multer({dest:'/uploads/'});

const storage = multer.diskStorage(
    {
        destination:"./public/images",
        filename:(req,file,cb)=>{
        return cb(null , `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
    }
  }
);

const upload=multer({
    storage : storage 
});

// router.post('/signin', (req, res) => {
//     db.query(`Select * from user where email_id=?`, [req.body.email_id], (err, results, feilds) => {
//         // console.log(req.body.email_id);
//         if (err) {
//             return res.status(401).send({
//                 sucess: 0,
//                 msg: err
//             })
//         }
//         if (!results.length) {

//             return res.status(401).send({
//                 sucess: false,
//                 msg: "Email id is Incorrect!"
//             })
//         }
//         else {
//             const token = jwt.sign({ data: results }, process.env.JWT_SECRER_KEY)

//             // const auth=req.headers.authorization.split(" ")[1];
//             // console.log(auth);

//             return res.status(201).send({
//                 sucess: true,
//                 msg: `User Login Sucessfull for user ${req.body.email_id}`,
//                 token: token
//             })
//         }
//     })
// })
router.post('/update_mobile_No', verifyToken, (req, res) => {
    db.query(`update user set mobile_no="${req.body.mobile_no}" where email_id="${req.body.email_id}"`, (err, result, feilds) => {
        if (err) {
            res.status(400).send({
                sucess: false,
                err: err.message
            })
        }
        else if (result) {
            db.query(`Update user SET updated_at=now() where email_id=?`, [req.body.email_id])
            res.status(201).send({
                sucess: true,
                results: result
            })
        }
    })
})
router.post("/signup", (req, res) => {
    db.query(`SELECT * FROM USER WHERE LOWER(email_id)=LOWER(?)`, [req.body.email_id], (err, result, feilds) => {
        if (result.length) {
            const token = jwt.sign({ data: result }, process.env.JWT_SECRER_KEY, { expiresIn: '30d' })
            return res.status(201).send({
                sucess: true,
                msg: "User Already Exist",
                results: result,
                token: token
            })
        }
        else if (!result.length) {
            db.query('Insert into user (email_id,user_name,google_id) values(?,?,?)', [req.body.email_id, req.body.user_name, req.body.google_id], (err, result, feilds) => {
                if (err) {
                    res.status(401).send({
                        sucess: false,
                        err: err.message,
                        err_no: err.errno
                    })
                }
                else if (result) {
                    db.query('Select * from user where email_id=?', [req.body.email_id], (err, bresult, feilds) => {
                        const token = jwt.sign({ data: result }, process.env.JWT_SECRER_KEY, { expiresIn: '30d' })
                        res.status(201).send({
                            sucess: true,
                            msg: "New User Created",
                            // email_id: req.body.email_id,
                            // useer_name: req.body.user_name,
                            // google_id: req.body.google_id,
                            results: bresult,
                            token: token
                        })
                    })
                }
            })
        }
        else if (err) {
            return res.status(401).send({
                sucess: false,
                err: err
            })
        }
    })
})
//POST:
//Add_new_Expense 
router.post('/add_new_Expense',upload.single('Select_image'), verifyToken, (req, res) => {

    //  var Image=req.file.filename
    
    db.query("Insert into add_new_expense(user_id,Category,Choose_expense_title,Total_amount,Select_image,Date,isRecurring) values(?,?,?,?,?,?,?)", [req.body.user_id, req.body.Category, req.body.Choose_Expense_title, req.body.Total_amount, req.body.Select_image
        , req.body.Date,req.body.isRecurring], (err, result, feilds) => {
            if (!err) {
                res.status(201).send({
                    success: true,
                    msg: `Expense added for user_id:${req.body.user_id}`,
                    results: result
                })
            }
            else if (err) {
                // console.log(err)
                res.status(401).send({
                    success: false,
                    err: err
                })
            }
        })
        // user_id  category  Choose_expense_title    Total_Amount Select_image  Date isRecurring
})
//Add Expense GET: 

router.post('/get_add_new_Expense', verifyToken, (req, res) => {
    db.query("Select * from add_new_expense where user_id=?", [req.body.user_id], (err, result, feilds) => {
        if (result) {
            if(!result.length){
            res.status(401).send({
                success:false,
                msg:`No Entry found for user_id:${req.body.user_id}`
            })
            }
            else{
            res.status(201).send({
                success: true,
                results: result
            })
        }
        }
        // if (result.length < 0) {
        //     res.status(401).send({
        //         success: false,
        //         msg: `user_id ${req.body.user_id} not found`
        //     })
        // }
        else if (err) {
            res.status(401).send({
                success: false,
                err: err
            })
        }
    })
})
router.post("/add_income", verifyToken, (req, res) => {


    db.query('Insert into add_income (user_id,Income_title,Amount,Date,Choose_Category) values(?,?,?,?,?) ', [req.body.user_id, req.body.Income_title, req.body.Amount, req.body.Date, req.body.Choose_Category], (err, result, feilds) => {
        if (!err) {
            res.status(201).send({
                success: true,
                message: `Entry added for user_id ${req.body.user_id}`,
                results: {
                    user_id: req.body.user_id,
                    Income_title: req.body.Income_title,
                    Amount: req.body.Amount,
                    Choose_Category: req.body.Choose_Category,
                    Date: req.body.Date
                }
                // Income_category: req.body.Income_category
            })
        }
        else if (err) {
            console.log(err);
            res.status(400).send({
                success: false,
                err: err.message
            })
        }

        if (result == null) {
            res.status(204).send({
                sucess: false,
                msg: "`Empty result json` Enter some values"
            })
        }

    })
})   //Add Income API post endsuser_

//Add_Income API get Request Starts
router.post("/get_add_income", verifyToken, (req, res) => {


    db.query('Select* from add_income where user_id=?', [req.body.user_id], (err, result, feilds) => {
        if (result) {
            // console.log(result);
            if(!result.length){
                res.status(401).send({
                    success:false,
                    msg:`No Entry found for user_id:${req.body.user_id}`
                })
            } 
                else{
            res.status(201).send({
                success: true,
                results: result
            })
        }
    }
        else if (err) {
            // console.log(err);
            res.status().send({
                success: false,
                err: err.message
            })
        }
    })
})
// Add Goal
//Add_Goal Route
// router.post("/add_goal", verifyToken, (req, res) => {

//     db.query('Insert into add_goal (user_id,Goal_Title,Amount,Contribution_Type,Deadline) values(?,?,?,?,?) ', [req.body.user_id, req.body.Goal_Title, req.body.Amount, req.body.Contribution_Type, req.body.Deadline], (err, result, feilds) => {
//         if (!err) {
//             res.status(201).send({
//                 success: true,
//                 message: `Entry added for user_id :${req.body.user_id}`,
//                 result: {
//                     user_id: req.body.user_id,
//                     Goal_Title: req.body.Goal_Title,
//                     Amount: req.body.amount,
//                     Contribution_Type: req.body.Contribution_Type,
//                     Deadline: req.body.Deadline
//                 }
//             })
//         }
//         else if (err) {
//             console.log(err);
//             res.status(400).send({
//                 success: false,
//                 err: err.message
//             })
//         }

//         else if (result == null) {
//             res.status(204).send({
//                 sucess: false,
//                 msg: "`Empty reesult json` Enter some values"
//             })
//         }

//     })
// })   //Add Goal API post ends

//Add_Goal API get Request Starts
router.post("/get_add_goal", verifyToken, (req, res) => {


    db.query('Select* from add_goal  where user_id=?', [req.body.user_id], (err, result, feilds) => {
        if (result) {
            // console.log(result);
            if(!result.length){
                res.status(401).send({
                    success:false,
                    msg:`No Entry found for user_id:${req.body.user_id}`
                })
                }
                else{ res.status(201).send({
                    success: true,
                    results: result
                })}
           
        }
        else if (err) {
            // console.log(err);
            res.status(400).send({
                success: false,
                err: err.message
            })
        }
    })
})  //Add Goal API get Request ends

// router.get('/getallUser',(req,res)=>{
//     if(!req.headers.autherization||
//         !req.headers.authorization.startsWith('Bearer')||
//         !req.headers.autherization.split(' ')[1]){
//             return res.status(422).send({
//                 sucess:0,
//                 message:"Please provide valid token"
//             });
//         }

//         const theToken=req.headers.autherization.split(' ')[1];
//         const decoded=jwt.verify(theToken,process.env.USER_TOKEN_SECRET);
//         db.query("Select * from user where email_id=?",[req.body.email_id],(err,result,feilds)=>{
//             if(err){
//             res.status(401).send({
//                 sucess:0,
//                 msg:err
//             })
//             }
//             if(result.length){
//                res.status(201).send({
//                 sucess:1,
//                 result:result
//                })
//             }
//         })


// })

// router.post('/exampleRoute', verifyToken, (req, res) => {
//     const auth = req.headers.authorization.split(' ')[1]
//     const decode = jwt.decode(auth);

//     let decoded_user_id = decode.data[0].user_id
//     console.log(decoded_user_id);
//     db.query('select * from add_new_expense1 where user_id=?', [decoded_user_id], (err, result, feilds) => {

//         // console.log(auth); 

//         if (err) {
//             res.status(401).send({
//                 sucess: false,
//                 err: err
//             })
//         }
//         if (result) {
//             res.status(201).send({
//                 sucess: true,
//                 result: result
//             })
//         }
//     })
// })


// router.post("/DemoResults",(req,res)=>{
//   db.query("Select * from add_new_expense",(err,resultsfor,feilds)=>{
//     if(resultsfor){
//         console.log(resultsfor);
//     }
//     if(err){
//         console.log(err)
//     }
//   })
// })

//Example get Add_Income Route Created for IOS Testing

router.post("/get_add_income_anurag", (req, res) => {


    db.query('Select* from add_income where user_id=?', [req.body.user_id], (err, anurag, feilds) => {
        if (anurag) {
            if(!anurag.length){
                res.status(401).send({
                    success:false,
                    msg:`No Entry found for user_id:${req.body.user_id}`
                })
                }
            // console.log(result);
            else{
            res.status(201).send({
                success: true,
                anurag: anurag
            })
        }
    }
        else if (err) {
            // console.log(err);
            res.status().send({
                success: false,
                err: err.message
            })
        }
    })
})

router.get('/category',upload.single('image'),(req,res)=>{
    db.query('Select * from category where categoryId=?',[req.body.categoryId],(err,result,feilds)=>{
        if(err){
            res.status(401).send({
                success:false,
                err:err
            })
        }
       if(result){
           res.status(201).send({
            success:true,
            image_url:`http://localhost:4000/profile/${result[0].image}`,
            results:result
           })
       }
    })
})

router.post('/category',upload.single("image"),(req,res)=>{
    var file=req.file.filename

    db.query('Update category set image=? where categoryId=?',[file,req.body.categoryId],(err,result,feilds)=>{
        if(err){
            res.status(400),send({
                success:false,
                err:err
            })
        }
        if(result){
            res.status(201).send({
                success:true,
                profile_url:`http://localhost:4000/profile/${file}`,
                results:result
            })
        }
    })
})

router.get('/getCategory',(req,res)=>{
    db.query('select * from category',(err,result,feilds)=>{
        if(err){
            res.status(400).send({
                success:false,
                err:err
            })
        }
        if(result){
            res.status(201).send({
                success:true,
                results:result
            })
        }
    })
})

router.post("/add_goal", verifyToken, (req, res) => {
     
    db.query('Insert into add_goal (user_id,Goal_Title,Amount,Contribution_Type,Deadline) values(?,?,?,?,?) ', [req.body.user_id, req.body.Goal_Title, req.body.Amount, req.body.Contribution_Type, req.body.Deadline], (err, result, feilds) => {
        if (err) {  
            console.log(err);
            res.status(400).send({
                success: false,
                err: err
            })
        }
        if (result) {
            db.query('select * from add_goal where user_id=? and goal_title =?',[req.body.user_id,req.body.Goal_Title],(goalerr,goalres,feilds)=>{
                 if(goalerr){
                    res.status(401).send({
                        success:false,
                        err:goalerr,
                        msg:"Entry Added in Goal Table but cant fetch added Data"
                    })
                 }
                 if(goalres){
                    console.log(goalres[0].Goal_id)
                    db.query('Insert into add_new_expense(user_id,category,goal_id,choose_expense_title,Total_Amount,Date,isRecurring) values(?,?,?,?,?,?,?)',[req.body.user_id,"Goals",goalres[0].Goal_id,req.body.Goal_Title,req.body.Amount,req.body.Deadline,'false'],(berr,bresult,feilds)=>{
                        if(berr){
                            res.status(401).send({
                                success:false,
                                msg:"Goal added but cant add in expense table",
                                err:berr
                            }) 
                        }
                         if(bresult){
                                res.status(201).send({
                                    success: true,
                                    message:`Entry added for user_id :${req.body.user_id}`,
                                    expense_status:"Goal Amount added in Expense",
                                    results: {
                                        user_id: req.body.user_id,
                                        Goal_Title: req.body.Goal_Title,
                                        Amount: req.body.amount,
                                        Contribution_Type: req.body.Contribution_Type,
                                        Deadline: req.body.Deadline
                                    }
                                })
                         }             
                    })
                 }

            })
           
         }
        else if (result == null) {
            res.status(204).send({
                sucess: false,
                msg: "`Empty result json` Enter some values"
            })
        }
    })
}) 

router.post('/getReccuring',(req,res)=>{
    db.query('select * from add_new_expense where user_id=? and isRecurring="true"',[req.body.user_id],(err,result,feilds)=>{
        if(err){
            res.status(401).send({
                success:true,
                error:err
            })
        }
        if(result){
            if(!result.length){
            res.status(401).send({
                success:false,
                msg:`No Entry found for user_id:${req.body.user_id}`
            })
            }
            else{
            res.status(201).send({
                success:true,
                results:result
            })
        }
        }
    })
})
// router.get('/getall',verifyToken,getall);

router.post('/Add_Money',(req,res)=>{
    db.query('select *,sum(Amount) from add_goal group by user_id having user_id=?',[req.body.user_id],(err,result,feilds)=>{
        if(err){
            res.status(401).send({
                success:false,
                err:err
          })
        }
        if(result){
            if(!result.length){
            res.status(401).send({
                success:false,
                msg:`No Entry found for user_id:${req.body.user_id}`
          })
        }else{
            res.status(201).send({
                success:true,
                results:result
            })
        }
      }
   })
})
router.post('/twoquery',(req,res)=>{
    db.query('select* from add_income desc add_income',(err,result)=>{
        if(err){
            console.log(err);
        }
        else if(result){
            console.log(result)
        }
    })
})
router.post('/add_new_expense/add_goal',(req,res)=>{
   db.query('Insert into add_new_expense')
})
module.exports = router