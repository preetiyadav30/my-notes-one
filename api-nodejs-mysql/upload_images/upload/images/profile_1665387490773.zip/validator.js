const { request, response } = require('express')
// const express=require('express')
require('dotenv').config();
const jwt=require('jsonwebtoken')

const verifyToken=(request,response,next)=>{
const autherization=request.headers.authorization;
try{
if(autherization){
    const theToken=autherization.split(' ')[1];
    // console.log(process.env.JWT_SECRER_KEY)
    jwt.verify(theToken,process.env.JWT_SECRER_KEY,(err,payload)=>{
        if(err){
            response.status(401).send({
                sucess:0,
                err:err
            })
        }
        else{
            next();
        }
    })
}
else {
    response.status(401).send({
        sucess:0,
        msg:"Please Enter Valid Token"
    })
 }
}
catch(err){
    return response.status(401).send("Invalid Token")
  }
}
module.exports=verifyToken